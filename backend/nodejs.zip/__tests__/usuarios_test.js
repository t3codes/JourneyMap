const request = require('supertest');
const express = require('express');
const { Usuario } = require('../models'); // Ajuste se necessário
const router = require('../routes/usuarios');
const { sequelize } = require('../config/database'); // Banco de dados real

// Configuração do servidor
const app = express();
app.use(express.json());
app.use('/api/usuarios', router);

describe('Usuarios API com dados reais', () => {
  beforeAll(async () => {
    // Sincronizar o banco de dados com as tabelas
    await sequelize.sync({ force: true });  // Usar force: true para resetar o banco antes dos testes
  });

  afterAll(async () => {
    // Fechar a conexão com o banco de dados após os testes
    await sequelize.close();
  });

  describe('POST /api/usuarios', () => {
    test('deve criar um usuário com dados reais', async () => {
      const usuarioData = {
        email: 'test@example.com',
        nome_completo: 'Test User',
        endereco: '123 Street',
        estado: 'SP',
        cidade: 'São Paulo',
        numero: '123',
        cep: '12345-678',
        senha: 'password123',
      };

      const response = await request(app).post('/api/usuarios').send(usuarioData);

      expect(response.status).toBe(201);
      expect(response.body.email).toBe(usuarioData.email);
      expect(response.body.nome_completo).toBe(usuarioData.nome_completo);
    });

    test('deve retornar 400 se campos obrigatórios estiverem faltando', async () => {
      const response = await request(app)
        .post('/api/usuarios')
        .send({ email: 'test@example.com' });

      expect(response.status).toBe(400);
      expect(response.body.error).toBe('Todos os campos são obrigatórios');
    });
  });

  describe('GET /api/usuarios', () => {
    test('deve retornar o usuário criado', async () => {
      const usuarioData = {
        email: 'test2@example.com',
        nome_completo: 'Test User 2',
        endereco: '456 Avenue',
        estado: 'RJ',
        cidade: 'Rio de Janeiro',
        numero: '456',
        cep: '65432-876',
        senha: 'password456',
      };

      // Criando usuário real no banco
      const usuario = await Usuario.create(usuarioData);

      const response = await request(app).get('/api/usuarios');

      expect(response.status).toBe(200);
      expect(response.body.email).toBe(usuarioData.email);
      expect(response.body.nome_completo).toBe(usuarioData.nome_completo);
    });

    test('deve retornar 404 se o usuário não for encontrado', async () => {
      const response = await request(app).get('/api/usuarios/99999');  // ID fictício
      expect(response.status).toBe(404);
      expect(response.body.error).toBe('Usuário não encontrado');
    });
  });

  describe('PUT /api/usuarios', () => {
    test('deve atualizar o usuário com dados reais', async () => {
      const usuarioData = {
        email: 'test3@example.com',
        nome_completo: 'Test User 3',
        endereco: '789 Street',
        estado: 'MG',
        cidade: 'Belo Horizonte',
        numero: '789',
        cep: '98765-432',
        senha: 'password789',
      };

      const usuario = await Usuario.create(usuarioData);

      const updateData = {
        nome_completo: 'Updated Test User 3',
      };

      const response = await request(app)
        .put(`/api/usuarios/${usuario.id}`)
        .send(updateData);

      expect(response.status).toBe(200);
      expect(response.body.nome_completo).toBe(updateData.nome_completo);
    });
  });

  describe('DELETE /api/usuarios', () => {
    test('deve deletar o usuário com dados reais', async () => {
      const usuarioData = {
        email: 'test4@example.com',
        nome_completo: 'Test User 4',
        endereco: '1010 Road',
        estado: 'BA',
        cidade: 'Salvador',
        numero: '1010',
        cep: '12345-678',
        senha: 'password1010',
      };

      const usuario = await Usuario.create(usuarioData);

      const response = await request(app).delete(`/api/usuarios/${usuario.id}`);

      expect(response.status).toBe(200);
      expect(response.body.message).toBe('Usuário deletado com sucesso');
    });
  });

  describe('POST /api/usuarios/login', () => {
    test('deve realizar login com dados reais', async () => {
      const usuarioData = {
        email: 'test5@example.com',
        nome_completo: 'Test User 5',
        endereco: '2020 Lane',
        estado: 'CE',
        cidade: 'Fortaleza',
        numero: '2020',
        cep: '22222-222',
        senha: 'password2020',
      };

      // Criando usuário real no banco
      const usuario = await Usuario.create(usuarioData);

      const response = await request(app)
        .post('/api/usuarios/login')
        .send({ email: usuario.email, senha: usuario.senha });

      expect(response.status).toBe(200);
      expect(response.body.message).toBe('Login realizado com sucesso');
    });

    test('deve retornar 401 se a senha for inválida', async () => {
      const usuarioData = {
        email: 'test6@example.com',
        nome_completo: 'Test User 6',
        endereco: '3030 Highway',
        estado: 'PR',
        cidade: 'Curitiba',
        numero: '3030',
        cep: '33333-333',
        senha: 'password3030',
      };

      const usuario = await Usuario.create(usuarioData);

      const response = await request(app)
        .post('/api/usuarios/login')
        .send({ email: usuario.email, senha: 'wrongpassword' });

      expect(response.status).toBe(401);
      expect(response.body.error).toBe('Credenciais inválidas');
    });
  });
});
