const request = require('supertest');
const express = require('express');
const { Usuario } = require('../models/Usuario');
const { sequelize } = require('../config/database');
const router = require('../routes/usuarios');

// Mock do middleware de verificação de token
jest.mock('../middlewares/verificaToken', () => (req, res, next) => {
  req.usuarioId = req.headers['x-user-id'] || 1; // Usa o ID do header ou 1 como padrão
  next();
});

const app = express();
app.use(express.json());
app.use('/api/usuarios', router);

describe('Usuarios API com dados reais', () => {
  let token; // Variável para armazenar o token do login

  beforeAll(async () => {
    await sequelize.sync({ force: true }); // Cria o banco em memória
  });

  afterAll(async () => {
    await sequelize.close(); // Fecha a conexão
  });

  describe('Fluxo de Registro e Login', () => {
    const usuarioData = {
      email: 'tharllesjhoines@gmail.com',
      nome_completo: 'Tharlles Jhoines Silva Té',
      endereco: 'Rua das Flores, 123',
      estado: 'SP',
      cidade: 'São Paulo',
      numero: '123',
      cep: '01234-567',
      senha: 'LiLEXXhP',
    };

    test('deve criar um usuário com sucesso', async () => {
      const response = await request(app)
        .post('/api/usuarios')
        .send(usuarioData);

      expect(response.status).toBe(201);
      expect(response.body.email).toBe(usuarioData.email);
      expect(response.body.nome_completo).toBe(usuarioData.nome_completo);
      expect(response.body.endereco).toBe(usuarioData.endereco);
      expect(response.body.estado).toBe(usuarioData.estado);
      expect(response.body.cidade).toBe(usuarioData.cidade);
      expect(response.body.numero).toBe(usuarioData.numero);
      expect(response.body.cep).toBe(usuarioData.cep);
    });

    test('deve retornar 400 ao tentar criar um usuário com email duplicado', async () => {
      const response = await request(app)
        .post('/api/usuarios')
        .send(usuarioData);

      expect(response.status).toBe(400);
      expect(response.body.error).toBe('Email já cadastrado');
    });

    test('deve realizar login com sucesso e armazenar o token', async () => {
      const loginData = {
        email: usuarioData.email,
        senha: usuarioData.senha,
      };

      const response = await request(app)
        .post('/api/usuarios/login')
        .send(loginData);

      expect(response.status).toBe(200);
      expect(response.body.message).toBe('Login realizado com sucesso');
      expect(response.body).toHaveProperty('token');

      // Armazena o token para uso nos testes subsequentes
      token = response.body.token;

      // Decodifica o token para obter o ID do usuário
      const decoded = require('jsonwebtoken').decode(token);
      expect(decoded.email).toBe(usuarioData.email);
      expect(decoded.nome_completo).toBe(usuarioData.nome_completo);
    });
  });

  describe('GET /api/usuarios', () => {
    test('deve retornar o usuário autenticado', async () => {
      // Cria um usuário para garantir que o ID 1 existe
      const usuarioData = {
        email: 'mockuser@example.com',
        nome_completo: 'Mock User',
        endereco: 'Mock Address',
        estado: 'SP',
        cidade: 'Mock City',
        numero: '1',
        cep: '11111-111',
        senha: 'mockpassword',
      };
      await Usuario.create({ id: 1, ...usuarioData });

      const response = await request(app)
        .get('/api/usuarios')
        .set('x-user-id', '1'); // Simula o ID do usuário via header

      expect(response.status).toBe(200);
      expect(response.body.email).toBe(usuarioData.email);
      expect(response.body.nome_completo).toBe(usuarioData.nome_completo);
    });

    test('deve retornar 404 se o usuário não for encontrado', async () => {
      await Usuario.destroy({ where: { id: 1 } }); // Remove o usuário com ID 1

      const response = await request(app)
        .get('/api/usuarios')
        .set('x-user-id', '1');

      expect(response.status).toBe(404);
      expect(response.body.error).toBe('Usuário não encontrado');
    });
  });

  describe('PUT /api/usuarios', () => {
    test('deve atualizar o usuário autenticado', async () => {
      const usuarioData = {
        email: 'updateuser@example.com',
        nome_completo: 'Update User',
        endereco: 'Update Address',
        estado: 'RJ',
        cidade: 'Rio de Janeiro',
        numero: '456',
        cep: '22222-222',
        senha: 'updatepassword',
      };
      await Usuario.create({ id: 1, ...usuarioData });

      const updateData = {
        nome_completo: 'Updated User Name',
        endereco: 'Updated Address',
      };

      const response = await request(app)
        .put('/api/usuarios')
        .set('x-user-id', '1')
        .send(updateData);

      expect(response.status).toBe(200);
      expect(response.body.nome_completo).toBe(updateData.nome_completo);
      expect(response.body.endereco).toBe(updateData.endereco);
    });

    test('deve retornar 400 se o email já estiver cadastrado', async () => {
      await Usuario.create({
        email: 'existing@example.com',
        nome_completo: 'Existing User',
        endereco: 'Existing Address',
        estado: 'SP',
        cidade: 'São Paulo',
        numero: '789',
        cep: '33333-333',
        senha: 'existingpassword',
      });

      const updateData = {
        email: 'existing@example.com',
      };

      const response = await request(app)
        .put('/api/usuarios')
        .set('x-user-id', '1')
        .send(updateData);

      expect(response.status).toBe(400);
      expect(response.body.error).toBe('Email já cadastrado');
    });
  });

  describe('DELETE /api/usuarios', () => {
    test('deve deletar o usuário autenticado', async () => {
      await Usuario.create({
        id: 1,
        email: 'deleteuser@example.com',
        nome_completo: 'Delete User',
        endereco: 'Delete Address',
        estado: 'SP',
        cidade: 'São Paulo',
        numero: '1010',
        cep: '44444-444',
        senha: 'deletepassword',
      });

      const response = await request(app)
        .delete('/api/usuarios')
        .set('x-user-id', '1');

      expect(response.status).toBe(200);
      expect(response.body.message).toBe('Usuário deletado com sucesso');

      const usuario = await Usuario.findByPk(1);
      expect(usuario).toBeNull();
    });

    test('deve retornar 404 se o usuário não for encontrado', async () => {
      await Usuario.destroy({ where: { id: 1 } });

      const response = await request(app)
        .delete('/api/usuarios')
        .set('x-user-id', '1');

      expect(response.status).toBe(404);
      expect(response.body.error).toBe('Usuário não encontrado');
    });
  });

  describe('POST /api/usuarios/login', () => {
    test('deve retornar 400 se email ou senha estiverem faltando', async () => {
      const response = await request(app)
        .post('/api/usuarios/login')
        .send({ email: 'test@example.com' });

      expect(response.status).toBe(400);
      expect(response.body.error).toBe('Email e senha são obrigatórios');
    });

    test('deve retornar 401 se o email não for encontrado', async () => {
      const response = await request(app)
        .post('/api/usuarios/login')
        .send({ email: 'nonexistent@example.com', senha: 'anypassword' });

      expect(response.status).toBe(401);
      expect(response.body.error).toBe('Credenciais inválidas');
    });

    test('deve retornar 401 se a senha for inválida', async () => {
      await Usuario.create({
        email: 'test6@example.com',
        nome_completo: 'Test User 6',
        endereco: '3030 Highway',
        estado: 'PR',
        cidade: 'Curitiba',
        numero: '3030',
        cep: '33333-333',
        senha: 'password3030',
      });

      const response = await request(app)
        .post('/api/usuarios/login')
        .send({ email: 'test6@example.com', senha: 'wrongpassword' });

      expect(response.status).toBe(401);
      expect(response.body.error).toBe('Credenciais inválidas');
    });
  });
});