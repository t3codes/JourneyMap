const request = require('supertest');
const express = require('express');
const jwt = require('jsonwebtoken');
const { Sequelize } = require('sequelize');
const { Usuario, Pais } = require('../models');
const paisRoutes = require('../routes/paisRoutes');
const usuarioRoutes = require('../routes/usuarios');

const JWT_SECRET = 'sua_chave_secreta';

// Configuração do servidor Express para testes
const app = express();
app.use(express.json());
app.use('/api/usuarios', usuarioRoutes); // Inclui rotas de usuário para login
app.use('/paises', paisRoutes);

// Mock do middleware verificaToken
jest.mock('../middlewares/verificaToken', () => (req, res, next) => {
  const authHeader = req.headers['authorization'];
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Token não fornecido' });
  }
  const token = authHeader.split(' ')[1];
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.usuarioId = decoded.id;
    next();
  } catch (error) {
    return res.status(401).json({ error: 'Token inválido' });
  }
});

// Configuração do banco de dados em memória
const sequelize = new Sequelize('sqlite::memory:', { logging: false });

describe('Testes dos Endpoints de Países', () => {
  let token; // Armazena o token do login

  beforeAll(async () => {
    // Sincroniza os modelos com o banco de dados em memória
    await sequelize.sync({ force: true });

    // Cria um usuário para os testes
    const usuarioData = {
      email: 'teste@exemplo.com',
      nome_completo: 'Usuário Teste',
      endereco: 'Rua Teste, 123',
      estado: 'SP',
      cidade: 'São Paulo',
      numero: '123',
      cep: '12345-678',
      senha: 'senha123',
    };

    await request(app).post('/api/usuarios').send(usuarioData);

    // Faz login para obter o token
    const loginResponse = await request(app)
      .post('/api/usuarios/login')
      .send({ email: usuarioData.email, senha: usuarioData.senha });

    token = loginResponse.body.token;
  });

  afterAll(async () => {
    // Fecha a conexão com o banco de dados
    await sequelize.close();
  });

  beforeEach(async () => {
    // Limpa a tabela Pais antes de cada teste
    await Pais.destroy({ where: {} });
  });

  describe('POST /paises', () => {
    const paisValido = {
      nome_comum: 'Brasil',
      nome_oficial: 'República do Brasil',
      regiao: 'América do Sul',
      moeda: 'Real',
      capital: 'Brasília',
      continente: 'América',
      link_png: 'https://example.com/brasil.png',
      link_googlemaps: 'https://maps.google.com/brasil',
      populacao: 213993437,
      official_name: 'Brazil',
      visited: false,
      observacoes: 'Planejo visitar em 2026.',
    };

    test('Deve criar um país com dados válidos', async () => {
      const response = await request(app)
        .post('/paises')
        .set('Authorization', `Bearer ${token}`)
        .send(paisValido);

      expect(response.status).toBe(201);
      expect(response.body).toHaveProperty('id');
      expect(response.body.nome_comum).toBe('Brasil');
      expect(response.body.usuarioId).toBe(1);
    });

    test('Deve retornar erro 400 se faltar um campo obrigatório', async () => {
      const paisInvalido = { ...paisValido, nome_comum: undefined };
      const response = await request(app)
        .post('/paises')
        .set('Authorization', `Bearer ${token}`)
        .send(paisInvalido);

      expect(response.status).toBe(400);
      expect(response.body.error).toBe('Todos os campos obrigatórios devem ser preenchidos');
    });

    test('Deve retornar erro 401 se o token não for fornecido', async () => {
      const response = await request(app)
        .post('/paises')
        .send(paisValido);

      expect(response.status).toBe(401);
      expect(response.body.error).toBe('Token não fornecido');
    });
  });

  describe('GET /paises', () => {
    test('Deve listar todos os países do usuário', async () => {
      await Pais.create({ ...paisValido, usuarioId: 1 });
      await Pais.create({
        ...paisValido,
        nome_comum: 'Japão',
        official_name: 'Japan',
        usuarioId: 1,
      });

      const response = await request(app)
        .get('/paises')
        .set('Authorization', `Bearer ${token}`);

      expect(response.status).toBe(200);
      expect(response.body).toHaveLength(2);
      expect(response.body[0].nome_comum).toBe('Brasil');
      expect(response.body[1].nome_comum).toBe('Japão');
    });

    test('Deve retornar lista vazia se o usuário não tiver países', async () => {
      const response = await request(app)
        .get('/paises')
        .set('Authorization', `Bearer ${token}`);

      expect(response.status).toBe(200);
      expect(response.body).toHaveLength(0);
    });

    test('Deve retornar erro 401 se o token não for fornecido', async () => {
      const response = await request(app).get('/paises');

      expect(response.status).toBe(401);
      expect(response.body.error).toBe('Token não fornecido');
    });
  });

  describe('GET /paises/:id', () => {
    const paisValido = {
      nome_comum: 'Brasil',
      nome_oficial: 'República do Brasil',
      regiao: 'América do Sul',
      moeda: 'Real',
      capital: 'Brasília',
      continente: 'América',
      link_png: 'https://example.com/brasil.png',
      link_googlemaps: 'https://maps.google.com/brasil',
      populacao: 213993437,
      official_name: 'Brazil',
      visited: false,
      observacoes: 'Planejo visitar em 2026.',
    };

    test('Deve retornar um país específico por ID', async () => {
      const pais = await Pais.create({ ...paisValido, usuarioId: 1 });

      const response = await request(app)
        .get(`/paises/${pais.id}`)
        .set('Authorization', `Bearer ${token}`);

      expect(response.status).toBe(200);
      expect(response.body.nome_comum).toBe('Brasil');
      expect(response.body.usuarioId).toBe(1);
    });

    test('Deve retornar erro 404 se o país não existir', async () => {
      const response = await request(app)
        .get('/paises/999')
        .set('Authorization', `Bearer ${token}`);

      expect(response.status).toBe(404);
      expect(response.body.error).toBe('País não encontrado ou não pertence ao usuário');
    });

    test('Deve retornar erro 401 se o token não for fornecido', async () => {
      const response = await request(app).get('/paises/1');

      expect(response.status).toBe(401);
      expect(response.body.error).toBe('Token não fornecido');
    });
  });

  describe('PUT /paises/:id', () => {
    const paisValido = {
      nome_comum: 'Brasil',
      nome_oficial: 'República do Brasil',
      regiao: 'América do Sul',
      moeda: 'Real',
      capital: 'Brasília',
      continente: 'América',
      link_png: 'https://example.com/brasil.png',
      link_googlemaps: 'https://maps.google.com/brasil',
      populacao: 213993437,
      official_name: 'Brazil',
      visited: false,
      observacoes: 'Planejo visitar em 2026.',
    };

    test('Deve atualizar um país com dados válidos', async () => {
      const pais = await Pais.create({ ...paisValido, usuarioId: 1 });

      const atualizacao = {
        visited: true,
        observacoes: 'Visitado em 2025, incrível!',
      };

      const response = await request(app)
        .put(`/paises/${pais.id}`)
        .set('Authorization', `Bearer ${token}`)
        .send(atualizacao);

      expect(response.status).toBe(200);
      expect(response.body.visited).toBe(true);
      expect(response.body.observacoes).toBe('Visitado em 2025, incrível!');
      expect(response.body.nome_comum).toBe('Brasil');
    });

    test('Deve retornar erro 404 se o país não existir', async () => {
      const response = await request(app)
        .put('/paises/999')
        .set('Authorization', `Bearer ${token}`)
        .send({ visited: true });

      expect(response.status).toBe(404);
      expect(response.body.error).toBe('País não encontrado ou não pertence ao usuário');
    });

    test('Deve retornar erro 401 se o token não for fornecido', async () => {
      const response = await request(app)
        .put('/paises/1')
        .send({ visited: true });

      expect(response.status).toBe(401);
      expect(response.body.error).toBe('Token não fornecido');
    });
  });

  describe('DELETE /paises/:id', () => {
    const paisValido = {
      nome_comum: 'Brasil',
      nome_oficial: 'República do Brasil',
      regiao: 'América do Sul',
      moeda: 'Real',
      capital: 'Brasília',
      continente: 'América',
      link_png: 'https://example.com/brasil.png',
      link_googlemaps: 'https://maps.google.com/brasil',
      populacao: 213993437,
      official_name: 'Brazil',
      visited: false,
      observacoes: 'Planejo visitar em 2026.',
    };

    test('Deve deletar um país existente', async () => {
      const pais = await Pais.create({ ...paisValido, usuarioId: 1 });

      const response = await request(app)
        .delete(`/paises/${pais.id}`)
        .set('Authorization', `Bearer ${token}`);

      expect(response.status).toBe(200);
      expect(response.body.message).toBe('País deletado com sucesso');

      const paisDeletado = await Pais.findByPk(pais.id);
      expect(paisDeletado).toBeNull();
    });

    test('Deve retornar erro 404 se o país não existir', async () => {
      const response = await request(app)
        .delete('/paises/999')
        .set('Authorization', `Bearer ${token}`);

      expect(response.status).toBe(404);
      expect(response.body.error).toBe('País não encontrado ou não pertence ao usuário');
    });

    test('Deve retornar erro 401 se o token não for fornecido', async () => {
      const response = await request(app).delete('/paises/1');

      expect(response.status).toBe(401);
      expect(response.body.error).toBe('Token não fornecido');
    });
  });
});